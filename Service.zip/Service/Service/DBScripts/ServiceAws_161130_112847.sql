-- ServiceRequest [pkg1#ent8]
alter table `servicerequest_2`  add column  `created_by`  varchar(255);


