-- ActivityInstance [ActivityInstance]
create table `activityinstance` (
   `oid`  integer  not null,
   `name`  varchar(255),
   `status`  varchar(255),
   `ready_since`  datetime,
   `active_since`  datetime,
   `completed_at`  datetime,
   `aborted_at`  datetime,
   `cancelled_at`  datetime,
   `worked_at`  datetime,
   `rollbackable`  bit,
   `context`  varchar(255),
  primary key (`oid`)
) ENGINE=InnoDB;
create index `idx_activityinstance_status` on `activityinstance`(`status`);


-- ActivityType [ActivityType]
create table `activitytype` (
   `oid`  integer  not null,
   `id`  varchar(255),
   `code`  varchar(255),
   `name`  varchar(255),
   `default_instance_name`  varchar(255),
   `description`  longtext,
   `type`  varchar(255),
   `execution`  varchar(255),
   `sort_number`  double precision,
   `uuid`  varchar(255),
  primary key (`oid`)
) ENGINE=InnoDB;
create index `idx_activitytype_type` on `activitytype`(`type`);
create index `idx_activitytype_execution` on `activitytype`(`execution`);
create index `idx_activitytype_uuid` on `activitytype`(`uuid`);


-- Attachment [Attachment]
create table `attachment` (
   `oid`  integer  not null,
   `file`  varchar(255),
   `title`  varchar(255),
   `timestamp`  datetime,
  primary key (`oid`)
) ENGINE=InnoDB;


-- Group [Group]
create table `group` (
   `oid`  integer  not null,
   `groupname`  varchar(255),
  primary key (`oid`)
) ENGINE=InnoDB;


-- Module [Module]
create table `module` (
   `oid`  integer  not null,
   `moduleid`  varchar(255),
   `modulename`  varchar(255),
   `moduledomainname`  varchar(255),
  primary key (`oid`)
) ENGINE=InnoDB;


-- Note [Note]
create table `note` (
   `oid`  integer  not null,
   `text`  longtext,
   `timestamp`  datetime,
  primary key (`oid`)
) ENGINE=InnoDB;


-- Notification [Notification]
create table `notification` (
   `oid`  integer  not null,
   `message`  varchar(255),
   `read`  bit,
  primary key (`oid`)
) ENGINE=InnoDB;


-- ParameterInstance [ParameterInstance]
create table `parameterinstance` (
   `oid`  integer  not null,
   `value`  varchar(255),
   `current`  bit,
   `timestamp`  datetime,
  primary key (`oid`)
) ENGINE=InnoDB;
create index `idx_parameterinstance_current` on `parameterinstance`(`current`);


-- ParameterType [ParameterType]
create table `parametertype` (
   `oid`  integer  not null,
   `name`  varchar(255),
   `description`  varchar(255),
   `type`  varchar(255),
  primary key (`oid`)
) ENGINE=InnoDB;
create index `idx_parametertype_name` on `parametertype`(`name`);


-- Process [Process]
create table `process` (
   `oid`  integer  not null,
   `code`  varchar(255),
   `name`  varchar(255),
   `default_instance_name`  varchar(255),
   `description`  longtext,
   `uuid`  varchar(255),
   `version`  varchar(255),
  primary key (`oid`)
) ENGINE=InnoDB;
create index `idx_process_uuid` on `process`(`uuid`);


-- ProcessInstance [ProcessInstance]
create table `processinstance` (
   `oid`  integer  not null,
   `name`  varchar(255),
   `subprocessindex`  integer,
   `status`  varchar(255),
   `active_since`  datetime,
   `completed_at`  datetime,
   `cancelled_at`  datetime,
   `aborted_at`  datetime,
  primary key (`oid`)
) ENGINE=InnoDB;
create index `idx_processinstance_status` on `processinstance`(`status`);


-- SequenceFlow [SequenceFlow]
create table `sequenceflow` (
   `oid`  integer  not null,
   `label`  varchar(255),
   `condition`  varchar(255),
   `default`  bit,
   `sort_number`  double precision,
  primary key (`oid`)
) ENGINE=InnoDB;


-- User [User]
create table `user` (
   `oid`  integer  not null,
   `username`  varchar(255),
   `password`  varchar(255),
   `email`  varchar(255),
  primary key (`oid`)
) ENGINE=InnoDB;


-- RepairFile [ent2]
create table `repairfile` (
   `oid`  integer  not null,
   `request_date`  date,
   `damage_description`  longtext,
   `time_estimate`  varchar(255),
   `repair_progress`  varchar(255),
   `image`  varchar(255),
  primary key (`oid`)
) ENGINE=InnoDB;


-- ActivityInstance_CandidateUser [ActivityInstance_CandidateUser]
create table `activityinstance_candidateuser` (
   `activityinstance_oid`  integer not null,
   `user_oid`  integer not null,
  primary key (`activityinstance_oid`, `user_oid`)
) ENGINE=InnoDB;
alter table `activityinstance_candidateuser`   add index fk_activityinstance_candidat_2 (`activityinstance_oid`), add constraint fk_activityinstance_candidat_2 foreign key (`activityinstance_oid`) references `activityinstance` (`oid`);
alter table `activityinstance_candidateuser`   add index fk_activityinstance_candidateu (`user_oid`), add constraint fk_activityinstance_candidateu foreign key (`user_oid`) references `user` (`oid`);


-- ActivityInstance_Group [ActivityInstance_Group]
alter table `activityinstance`  add column  `group_oid`  integer;
alter table `activityinstance`   add index fk_activityinstance_group (`group_oid`), add constraint fk_activityinstance_group foreign key (`group_oid`) references `group` (`oid`);


-- ActivityInstance_NextActivityInstanceNotes [ActivityInstance_NextActivityInstanceNotes]
alter table `note`  add column  `activityinstance_oid`  integer;
alter table `note`   add index fk_note_activityinstance (`activityinstance_oid`), add constraint fk_note_activityinstance foreign key (`activityinstance_oid`) references `activityinstance` (`oid`);


-- ActivityInstance_Notification [ActivityInstance_Notifications]
alter table `notification`  add column  `activityinstance_oid`  integer;
alter table `notification`   add index fk_notification_activityinstan (`activityinstance_oid`), add constraint fk_notification_activityinstan foreign key (`activityinstance_oid`) references `activityinstance` (`oid`);


-- ActivityType_ActivityInstance [ActivityType_ActivityInstance]
alter table `activityinstance`  add column  `activitytype_oid`  integer;
alter table `activityinstance`   add index fk_activityinstance_activityty (`activitytype_oid`), add constraint fk_activityinstance_activityty foreign key (`activitytype_oid`) references `activitytype` (`oid`);


-- Attachment_ProcessInstance [Attachment_ProcessInstance]
create table `attachment_processinstance` (
   `attachment_oid`  integer not null,
   `processinstance_oid`  integer not null,
  primary key (`attachment_oid`, `processinstance_oid`)
) ENGINE=InnoDB;
alter table `attachment_processinstance`   add index fk_attachment_processinstance (`attachment_oid`), add constraint fk_attachment_processinstance foreign key (`attachment_oid`) references `attachment` (`oid`);
alter table `attachment_processinstance`   add index fk_attachment_processinstanc_2 (`processinstance_oid`), add constraint fk_attachment_processinstanc_2 foreign key (`processinstance_oid`) references `processinstance` (`oid`);


-- Attachment_User [Attachment_User]
alter table `attachment`  add column  `user_oid`  integer;
alter table `attachment`   add index fk_attachment_user (`user_oid`), add constraint fk_attachment_user foreign key (`user_oid`) references `user` (`oid`);


-- Group_DefaultModule [Group2DefaultModule_DefaultModule2Group]
alter table `group`  add column  `module_oid`  integer;
alter table `group`   add index fk_group_module (`module_oid`), add constraint fk_group_module foreign key (`module_oid`) references `module` (`oid`);


-- Group_Module [Group2Module_Module2Group]
create table `group_module` (
   `group_oid`  integer not null,
   `module_oid`  integer not null,
  primary key (`group_oid`, `module_oid`)
) ENGINE=InnoDB;
alter table `group_module`   add index fk_group_module_group (`group_oid`), add constraint fk_group_module_group foreign key (`group_oid`) references `group` (`oid`);
alter table `group_module`   add index fk_group_module_module (`module_oid`), add constraint fk_group_module_module foreign key (`module_oid`) references `module` (`oid`);


-- Group_ActivityType [Group_ActivityType]
create table `group_activitytype` (
   `group_oid`  integer not null,
   `activitytype_oid`  integer not null,
  primary key (`group_oid`, `activitytype_oid`)
) ENGINE=InnoDB;
alter table `group_activitytype`   add index fk_group_activitytype_group (`group_oid`), add constraint fk_group_activitytype_group foreign key (`group_oid`) references `group` (`oid`);
alter table `group_activitytype`   add index fk_group_activitytype_activity (`activitytype_oid`), add constraint fk_group_activitytype_activity foreign key (`activitytype_oid`) references `activitytype` (`oid`);


-- NextActivityType_PreviousSequenceFlow [NextActivityType_PreviousSequenceFlow]
alter table `sequenceflow`  add column  `activitytype_oid`  integer;
alter table `sequenceflow`   add index fk_sequenceflow_activitytype (`activitytype_oid`), add constraint fk_sequenceflow_activitytype foreign key (`activitytype_oid`) references `activitytype` (`oid`);


-- Note_ActivityInstance [Note_ActivityInstance]
create table `note_activityinstance` (
   `note_oid`  integer not null,
   `activityinstance_oid`  integer not null,
  primary key (`note_oid`, `activityinstance_oid`)
) ENGINE=InnoDB;
alter table `note_activityinstance`   add index fk_note_activityinstance_note (`note_oid`), add constraint fk_note_activityinstance_note foreign key (`note_oid`) references `note` (`oid`);
alter table `note_activityinstance`   add index fk_note_activityinstance_activ (`activityinstance_oid`), add constraint fk_note_activityinstance_activ foreign key (`activityinstance_oid`) references `activityinstance` (`oid`);


-- Note_ProcessInstance [Note_ProcessInstance]
create table `note_processinstance` (
   `note_oid`  integer not null,
   `processinstance_oid`  integer not null,
  primary key (`note_oid`, `processinstance_oid`)
) ENGINE=InnoDB;
alter table `note_processinstance`   add index fk_note_processinstance_note (`note_oid`), add constraint fk_note_processinstance_note foreign key (`note_oid`) references `note` (`oid`);
alter table `note_processinstance`   add index fk_note_processinstance_proces (`processinstance_oid`), add constraint fk_note_processinstance_proces foreign key (`processinstance_oid`) references `processinstance` (`oid`);


-- Note_User [Note_User]
alter table `note`  add column  `user_oid`  integer;
alter table `note`   add index fk_note_user (`user_oid`), add constraint fk_note_user foreign key (`user_oid`) references `user` (`oid`);


-- ParameterInstance_ActivityInstance [ParameterInstance_ActivityInstance]
alter table `parameterinstance`  add column  `activityinstance_oid`  integer;
alter table `parameterinstance`   add index fk_parameterinstance_activityi (`activityinstance_oid`), add constraint fk_parameterinstance_activityi foreign key (`activityinstance_oid`) references `activityinstance` (`oid`);


-- ParameterType_ParameterInstance [ParameterType_ParameterInstance]
alter table `parameterinstance`  add column  `parametertype_oid`  integer;
alter table `parameterinstance`   add index fk_parameterinstance_parameter (`parametertype_oid`), add constraint fk_parameterinstance_parameter foreign key (`parametertype_oid`) references `parametertype` (`oid`);


-- PreviousActivityInstance_NextActivityInstance [PreviousActivityInstance_NextActivityInstance]
create table `previousactivityinstance_nexta` (
   `activityinstance_oid_2`  integer not null,
   `activityinstance_oid`  integer not null,
  primary key (`activityinstance_oid_2`, `activityinstance_oid`)
) ENGINE=InnoDB;
alter table `previousactivityinstance_nexta`   add index fk_previousactivityinstance_ne (`activityinstance_oid_2`), add constraint fk_previousactivityinstance_ne foreign key (`activityinstance_oid_2`) references `activityinstance` (`oid`);
alter table `previousactivityinstance_nexta`   add index fk_previousactivityinstance_2 (`activityinstance_oid`), add constraint fk_previousactivityinstance_2 foreign key (`activityinstance_oid`) references `activityinstance` (`oid`);


-- PreviousActivityType_NextSequenceFlow [PreviousActivityType_NextSequenceFlow]
alter table `sequenceflow`  add column  `activitytype_oid_2`  integer;
alter table `sequenceflow`   add index fk_sequenceflow_activitytype_2 (`activitytype_oid_2`), add constraint fk_sequenceflow_activitytype_2 foreign key (`activitytype_oid_2`) references `activitytype` (`oid`);


-- ProcessInstance_ActivityInstance [ProcessInstance_ActivityInstance]
alter table `activityinstance`  add column  `processinstance_oid`  integer;
alter table `activityinstance`   add index fk_activityinstance_processins (`processinstance_oid`), add constraint fk_activityinstance_processins foreign key (`processinstance_oid`) references `processinstance` (`oid`);


-- ProcessInstance_ParameterInstance [ProcessInstance_ParameterInstance]
alter table `parameterinstance`  add column  `processinstance_oid`  integer;
alter table `parameterinstance`   add index fk_parameterinstance_processin (`processinstance_oid`), add constraint fk_parameterinstance_processin foreign key (`processinstance_oid`) references `processinstance` (`oid`);


-- ProcessInstance_Process [ProcessInstance_Process]
alter table `processinstance`  add column  `process_oid`  integer;
alter table `processinstance`   add index fk_processinstance_process (`process_oid`), add constraint fk_processinstance_process foreign key (`process_oid`) references `process` (`oid`);


-- Process_ActivityType [Process_ActivityType]
alter table `activitytype`  add column  `process_oid`  integer;
alter table `activitytype`   add index fk_activitytype_process (`process_oid`), add constraint fk_activitytype_process foreign key (`process_oid`) references `process` (`oid`);


-- Process_ParameterType [Process_ParameterType]
alter table `parametertype`  add column  `process_oid`  integer;
alter table `parametertype`   add index fk_parametertype_process (`process_oid`), add constraint fk_parametertype_process foreign key (`process_oid`) references `process` (`oid`);


-- SubprocessInstances_ParentProcessInstance [SubprocessInstances_ParentProcessInstance]
alter table `processinstance`  add column  `processinstance_oid`  integer;
alter table `processinstance`   add index fk_processinstance_processinst (`processinstance_oid`), add constraint fk_processinstance_processinst foreign key (`processinstance_oid`) references `processinstance` (`oid`);


-- User_DefaultGroup [User2DefaultGroup_DefaultGroup2User]
alter table `user`  add column  `group_oid`  integer;
alter table `user`   add index fk_user_group (`group_oid`), add constraint fk_user_group foreign key (`group_oid`) references `group` (`oid`);


-- User_Group [User2Group_Group2User]
create table `user_group` (
   `user_oid`  integer not null,
   `group_oid`  integer not null,
  primary key (`user_oid`, `group_oid`)
) ENGINE=InnoDB;
alter table `user_group`   add index fk_user_group_user (`user_oid`), add constraint fk_user_group_user foreign key (`user_oid`) references `user` (`oid`);
alter table `user_group`   add index fk_user_group_group (`group_oid`), add constraint fk_user_group_group foreign key (`group_oid`) references `group` (`oid`);


-- User_ActivityInstance [User_ActivityInstance]
alter table `activityinstance`  add column  `user_oid`  integer;
alter table `activityinstance`   add index fk_activityinstance_user (`user_oid`), add constraint fk_activityinstance_user foreign key (`user_oid`) references `user` (`oid`);


-- User_Notifications [User_Notifications]
create table `user_notifications` (
   `user_oid`  integer not null,
   `notification_oid`  integer not null,
  primary key (`user_oid`, `notification_oid`)
) ENGINE=InnoDB;
alter table `user_notifications`   add index fk_user_notifications_user (`user_oid`), add constraint fk_user_notifications_user foreign key (`user_oid`) references `user` (`oid`);
alter table `user_notifications`   add index fk_user_notifications_notifica (`notification_oid`), add constraint fk_user_notifications_notifica foreign key (`notification_oid`) references `notification` (`oid`);


-- ProcessInstance.attachment count [processInstanceAttachmentCount]
create view `processinstance_attachment_cou` as
select AL1.`oid` as `oid`, count(distinct AL2.`attachment_oid`) as `der_attr`
from  `processinstance` AL1 
               left outer join `attachment_processinstance` AL2 on AL1.`oid`=AL2.`processinstance_oid`
group by AL1.`oid`;


