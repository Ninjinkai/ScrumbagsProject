-- ServiceRequest [pkg1#ent8]
alter table `servicerequest_2`  add column  `photo_2`  varchar(255);
alter table `servicerequest_2`  add column  `photoblob`  longblob;


