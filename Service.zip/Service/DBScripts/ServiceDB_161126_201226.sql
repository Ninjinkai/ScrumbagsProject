-- ServiceRequest [pkg1#ent8]
alter table "APP"."SERVICEREQUEST_2"  add column  "STATUS"  varchar(255);


